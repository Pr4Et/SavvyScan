#!/usr/bin/env python

from eigerclient import DEigerClient
import argparse


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description = "Acquire and download image(s) using the FileWriter Interface")

    parser.add_argument("-i", "--ip", help="host ip", type=str, required=True)
    parser.add_argument("-p", "--port", help="host port", type=str, required=False, default=80)
    parser.add_argument("-d", "--download-dir", help="download file(s) to directory", type=str, default=".")
    parser.add_argument("-x", "--delete_files", help="delete files on server after download", action='store_true')

    args = parser.parse_args()

    client = DEigerClient.DEigerClient(args.ip, args.port)

    files = client.fileWriterFiles()["value"]
    
    for file in files:
        if args.download_dir != "":
            print(f'Downloading {file}')
            client.fileWriterSave(file, args.download_dir)
            
        if args.delete_files:
            print(f'Deleting {file}')
            client.fileWriterFiles(file, "DELETE")

    print('Script finished')
