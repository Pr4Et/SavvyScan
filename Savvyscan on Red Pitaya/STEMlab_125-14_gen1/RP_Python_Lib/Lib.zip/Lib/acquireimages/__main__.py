#!/usr/bin/env python

from eigerclient import DEigerClient
import argparse
import time
import tifffile
import numpy
import json
from base64 import b64encode
import requests

import socket

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description = "Acquire and download image(s) using the FileWriter Interface")

    parser.add_argument("-i", "--ip", help="host ip", type=str, required=True)
    parser.add_argument("-p", "--port", help="host port", type=str, required=False, default=80)
    parser.add_argument("-t", "--frame-time", help="frame time per image in seconds", type=float, default=1)
    parser.add_argument("-n", "--nimages", help="number of images", type=int, default=1)
    parser.add_argument("-e", "--energy", help="incident particle energy in keV", type=int, required=False)
    parser.add_argument("-th", "--threshold-energy", help="threshold energy in keV", type=float, required=False)
    parser.add_argument("-o", "--name-pattern", help="filename", type=str, default="out")
    parser.add_argument("-f", "--flatfield", help="filename of flat illuminated tif", type=str, required=False)
    parser.add_argument("-d", "--download-dir", help="download file(s) to directory", type=str, default=".")
    parser.add_argument("-x", "--ext-trigger", help="wait for external trigger per image", action='store_true')
    parser.add_argument("-fi", "--force-initialize", help="force initializing the detector", action='store_true')

    args = parser.parse_args()

    try:
        socket.create_connection((args.ip, args.port), timeout=2)
    except Exception as e:
        print("ERROR: Cannot reach camera:", e)
        exit(1)

    client = DEigerClient.DEigerClient(args.ip, args.port)

    if args.force_initialize:
        client.sendDetectorCommand("initialize")
    else:
        if client.detectorStatus("state")["value"] == "ready":
            client.sendDetectorCommand("disarm")

        if client.detectorStatus("state")["value"] == "acquire":
            print("The detector is currently acquiring images. Do you want to cancel the acquisition (y/n): y")
            answer = "y"
            if answer == "y":
                print('Abort image acquisition')
                client.sendDetectorCommand("abort")
            else:
                print('Exiting')
                exit()

        if client.detectorStatus("state")["value"] != "idle":
            print("The detector is not in idle state. Do you want to initialize the detector? (y/n): y")
            answer = "y"
            if answer == "y":
                print('Initialize detector')
                client.sendDetectorCommand("initialize")
            else:
                print('Exiting')
                exit()
    
    print('Enabling FileWriter interface')
    client.setFileWriterConfig('mode', 'enabled')
    client.setFileWriterConfig('name_pattern', args.name_pattern)
    client.setFileWriterConfig('nimages_per_file', 100000)
    
    print('Configuring detector acquisition settings')
    if args.energy:
        if "photon_energy" in client.detectorConfig('keys'):
            client.setDetectorConfig('photon_energy', args.energy * 1000)
        else:
            client.setDetectorConfig('incident_energy', args.energy * 1000)
    
    if args.threshold_energy:
        if "threshold_energy" in client.detectorConfig('keys'):
            client.setDetectorConfig('threshold_energy', args.threshold_energy * 1000)
        else:
            print('Detector does not allow setting the threshold. Skipping.')
            
    if args.ext_trigger:
        client.setDetectorConfig('trigger_mode', 'exts')
        client.setDetectorConfig('nimages', 1)
        client.setDetectorConfig('ntrigger', args.nimages)
    else:
        client.setDetectorConfig('ntrigger', 1)
        client.setDetectorConfig('nimages', args.nimages)
        
    #Set acquisition mode based on frame_time
    frame_rate = 1.0 / args.frame_time
    
    #Workaraound for switching to lower framerates
    client.setDetectorConfig('count_time', 1)
    client.setDetectorConfig('frame_time', 1)

    if "pixel_format" in client.detectorConfig('keys'):
        if frame_rate <= 20000:
            client.setDetectorConfig('binning_mode', '1x1')
            client.setDetectorConfig('pixel_format', 'UINT12_BE')
        elif frame_rate <= 30000:
            client.setDetectorConfig('binning_mode', '1x1')
            client.setDetectorConfig('pixel_format', 'FLOAT8_53')
        elif frame_rate <= 80000:
            client.setDetectorConfig('binning_mode', '2x2')
            client.setDetectorConfig('pixel_format', 'UINT12_BE')
        else:
            client.setDetectorConfig('binning_mode', '2x2')
            client.setDetectorConfig('pixel_format', 'FLOAT8_53')

    readout_time = client.detectorConfig('detector_readout_time')['value']
    
    client.setDetectorConfig('count_time', args.frame_time - readout_time)
    client.setDetectorConfig('frame_time', args.frame_time)
    
    numberOfImagesPerFile = client.fileWriterConfig('nimages_per_file')['value']
    numerOfDataFiles = int((args.nimages - 1) / numberOfImagesPerFile) + 1

    data_files = [args.name_pattern + "_master.h5"]
    data_files += [args.name_pattern + "_data_{:06d}.h5".format(i+1) for i in range(numerOfDataFiles)]

    if args.flatfield:
        flatfield_data = tifffile.imread(args.flatfield)
        flatfield_data = numpy.median(flatfield_data) / flatfield_data.astype('float32')
        url = 'http://%s:%s/detector/api/%s/config/flatfield' % (args.ip, args.port, "1.8.0")
        data = json.dumps({"value": {"__darray__": (1, 0, 0),
                                     "type": flatfield_data.dtype.str,
                                     "shape": flatfield_data.shape,
                                     "filters": ["base64"],
                                     "data": b64encode(flatfield_data.data).decode('utf-8')}})
        reply = requests.put(url, data=data, headers={'Content-Type': 'application/json'})
        assert reply.status_code in range(200, 300), reply.reason
        client.setDetectorConfig("flatfield_correction_applied", True)
    else:
        client.setDetectorConfig("flatfield_correction_applied", False)


    print('\nAcquisition settings:')
    print('\t Exposure time per image: {} s'.format(client.detectorConfig("count_time")["value"]))
    print('\t Framerate: {} Hz'.format(1.0 / client.detectorConfig("frame_time")["value"]))
    print('\t ROI mode: {}'.format(client.detectorConfig("roi_mode")["value"]))

    if "pixel_format" in client.detectorConfig('keys'):
        print('\t Pixel Format: {}'.format(client.detectorConfig("pixel_format")["value"]))

    print('\t Number of images per trigger: {}'.format(client.detectorConfig("nimages")["value"]))
    print('\t Number of triggers: {}'.format(client.detectorConfig("ntrigger")["value"]))
    print('\t Trigger mode: {}'.format(client.detectorConfig("trigger_mode")["value"]))

    if "incident_energy" in client.detectorConfig('keys'):
        print('\t Incident energy: {} eV\n'.format(client.detectorConfig("incident_energy")["value"]))
    else:
        print('\t Incident energy: {} eV\n'.format(client.detectorConfig("photon_energy")["value"]))

    if "threshold_energy" in client.detectorConfig('keys'):
        print('\t Threshold energy: {} eV\n'.format(client.detectorConfig("threshold_energy")["value"]))
    else:
        pass
        
    print('Arming detector')
    client.sendDetectorCommand('arm')
    
    if args.ext_trigger:
        print('Waiting for external trigger signals')
        while client.detectorStatus("state")["value"] != "idle":
            time.sleep(0.5)
        print('Acquisition finished')
    else:
        print('Starting acquisition')
        client.sendDetectorCommand('trigger')
        print('Acquisition finished')
    
    #To save after record 28 Nov 2022
    #while client.fileWriterStatus("state")["value"] != "ready":
    #    time.sleep(0.5)
    
    #for file in data_files:
    #    print(f'Downloading {file}')
    #    client.fileWriterSave(file, args.download_dir)
    #    client.fileWriterFiles(file, "DELETE")

    print('Script finished')
